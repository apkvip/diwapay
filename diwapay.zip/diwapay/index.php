<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DiwaPay VIP</title>

    <!-- Open Graph -->
    <meta property="og:title" contencon="DiwaPay VIP">
    <meta property="og:description" content="DiwaPay VIP">
    <meta property="og:url" content="https://diwapay.vipteam.pro">
    <meta property="og:type" content="website">


    


<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{
background:#2141b5;
overflow-x:hidden;
color:#fff;
}

/* TOPBAR */
.topbar{
width:100%;
background:#1f3faa;
padding:10px;
display:flex;
justify-content:space-between;
align-items:center;
box-shadow:0 2px 10px rgba(0,0,0,0.2);
position:sticky;
top:0;
z-index:999;
}

.logo-area{
display:flex;
align-items:center;
gap:10px;
}

.logo-area img{
width:42px;
height:42px;
border-radius:10px;
background:#fff;
padding:3px;
}

.logo-text h2{
font-size:17px;
font-weight:700;
line-height:1;
}

.logo-text p{
font-size:12px;
margin-top:3px;
opacity:.9;
}

.top-download{
background:#ff8b12;
color:#fff;
border:none;
padding:11px 18px;
font-size:14px;
font-weight:700;
border-radius:15px;
box-shadow:0 4px 10px rgba(0,0,0,0.25);
cursor:pointer;
}

/* HERO */
.hero{
padding:20px 14px 10px;
text-align:center;
}

.hero h1{
font-size:24px;
font-weight:800;
line-height:1.25;
margin-bottom:22px;
text-shadow:0 4px 8px rgba(0,0,0,0.25);
}

.hero-img img{
width:82%;
max-width:300px;
}

/* DOWNLOAD BUTTON */
.big-download{
margin-top:22px;
}

.big-download button{
width:82%;
padding:15px;
font-size:19px;
font-weight:700;
border:none;
border-radius:16px;
background:#ff8b12;
color:#fff;
cursor:pointer;
box-shadow:
0 5px 0 #d96e00,
0 10px 18px rgba(0,0,0,0.25);
}

/* TITLE */
.section-title{
width:88%;
margin:28px auto 16px;
background:rgba(255,255,255,0.08);
padding:14px;
border-radius:18px;
text-align:center;
font-size:18px;
font-weight:700;
box-shadow:inset 0 0 0 2px rgba(255,255,255,0.08);
}

/* FEATURES */
.features{
width:90%;
margin:auto;
background:#cfd6ec;
border-radius:22px;
padding:18px 6px;
display:flex;
justify-content:space-between;
gap:6px;
}

.feature{
flex:1;
text-align:center;
}

.icon-box{
width:72px;
height:72px;
background:#fff;
margin:auto;
border-radius:18px;
display:flex;
justify-content:center;
align-items:center;
font-size:32px;
box-shadow:0 5px 14px rgba(0,0,0,0.15);
}

.feature h3{
margin-top:10px;
font-size:14px;
color:#16328d;
}

.feature p{
margin-top:4px;
font-size:11px;
color:#41548f;
line-height:1.3;
}

/* EXTRA DOWNLOAD */
.extra-download{
text-align:center;
margin-top:28px;
}

.extra-download button{
width:82%;
padding:15px;
font-size:18px;
font-weight:700;
border:none;
border-radius:16px;
background:#ff8b12;
color:#fff;
cursor:pointer;
box-shadow:
0 5px 0 #d46d00,
0 10px 20px rgba(0,0,0,0.25);
}

/* WHY BOX */
.why-box{
width:92%;
margin:28px auto;
background:#1d3ea8;
border-radius:24px;
padding:18px 14px 22px;
box-shadow:0 8px 20px rgba(0,0,0,0.2);
}

.why-title{
background:#ececf2;
color:#16328d;
font-size:18px;
font-weight:800;
text-align:center;
padding:18px;
border-radius:20px;
margin-bottom:24px;
}

.why-content h3{
font-size:16px;
margin-bottom:8px;
margin-top:18px;
font-weight:800;
}

.why-content p{
font-size:13px;
line-height:1.5;
color:#e6e6e6;
}

.join-box{
background:#ececf2;
color:#16328d;
font-size:15px;
font-weight:800;
text-align:center;
padding:22px 14px;
border-radius:18px;
margin-top:28px;
line-height:1.5;
}

/* REBATE */
.rebate-section{
width:92%;
margin:28px auto 40px;
background:#1d3ea8;
border-radius:24px;
padding:18px 14px 22px;
box-shadow:0 8px 20px rgba(0,0,0,0.2);
}

.rebate-title{
background:#ececf2;
color:#16328d;
font-size:18px;
font-weight:800;
text-align:center;
padding:18px;
border-radius:20px;
margin-bottom:28px;
}

.rebate-grid{
display:flex;
justify-content:space-between;
gap:16px;
}

.rebate-card{
flex:1;
border-radius:22px;
padding:18px 10px;
text-align:center;
color:#fff;
box-shadow:0 8px 18px rgba(0,0,0,0.25);
}

.level-a{
background:linear-gradient(180deg,#7eb0ff,#4b68d8);
}

.level-b{
background:linear-gradient(180deg,#ff6d75,#e54855);
}

.rebate-card h2{
font-size:18px;
margin-bottom:18px;
}

.percent-box{
background:#f2f2f2;
color:#16328d;
font-size:22px;
font-weight:800;
width:80%;
margin:auto;
padding:14px 0;
border-radius:999px;
margin-bottom:18px;
}

.rebate-card p{
font-size:13px;
}

.download-link{
text-decoration:none;
}


html,body{width:100%;max-width:100%;overflow-x:hidden;}
.hero h1{font-size:clamp(20px,5vw,28px);}
.hero-img img{width:100%;max-width:300px;height:auto;}
.big-download button,.extra-download button{width:100%;max-width:340px;}
.features{flex-wrap:wrap;justify-content:center;gap:10px;}
.feature{flex:1 1 90px;min-width:90px;}
.rebate-grid{flex-wrap:wrap;gap:12px;}
.rebate-card{flex:1 1 140px;}
@media(max-width:480px){
.logo-text h2{font-size:15px;}
.logo-text p{font-size:11px;}
.top-download{padding:10px 14px;font-size:13px;}
.icon-box{width:60px;height:60px;font-size:28px;}
}

</style>

</head>

<body>

<!-- TOPBAR -->
<div class="topbar">

<div class="logo-area">

<img src="logo.png">

<div class="logo-text">
<h2>DiwaPay VIP</h2>
<p>Earn Money Online👑</p>
</div>

</div>

<a class="download-link"
href="DiwaPayVIP.apk"
download>

<button class="top-download" type="button">
Download
</button>

</a>

</div>

<!-- HERO -->
<div class="hero">

<h1>
👑DiwaPay VIP👑<br>
🏭ALL TASK 8% REWARD🏭
</h1>

<div class="hero-img">
<img src="hero.png">
</div>

<div class="big-download">

<a class="download-link"
href="DiwaPayVIP.apk"
download>

<button type="button">
Download
</button>

</a>

</div>

</div>

<!-- TITLE -->
<div class="section-title">
Earn Money Online
</div>

<!-- FEATURES -->
<div class="features">

<div class="feature">
<div class="icon-box">🧠</div>
<h3>Easy task</h3>
<p>To get Rupee</p>
</div>

<div class="feature">
<div class="icon-box">⚡</div>
<h3>Super-fast</h3>
<p>Withdrawal</p>
</div>

<div class="feature">
<div class="icon-box">👍</div>
<h3>Refer</h3>
<p>And Earn</p>
</div>

</div>

<!-- EXTRA DOWNLOAD -->
<div class="extra-download">

<a class="download-link"
href="DiwaPayVIP.apk"
download>

<button type="button">
Download
</button>

</a>

</div>

<!-- WHY CHOOSE -->
<div class="why-box">

<div class="why-title">
Why choose our platform?
</div>

<div class="why-content">

<h3>Trusted Protection:</h3>
<p>
Backed by industry-recognized partners, delivering a stable and reliable earning environment.
</p>

<h3>Quick experience:</h3>
<p>
Smooth task flow, easy money earning.
</p>

<h3>Massive orders:</h3>
<p>
Diverse tasks, suitable for both part-time and full-time work!
</p>

</div>

<div class="join-box">
Join us and earn money efficiently. Safer, faster, more reliable!
</div>

</div>

<!-- RECHARGE REBATE -->
<div class="rebate-section">

<div class="rebate-title">
Recharge rebate
</div>

<div class="rebate-grid">

<div class="rebate-card level-a">

<h2>level A</h2>

<div class="percent-box">
3%
</div>

<p>Profit Ratio</p>

</div>

<div class="rebate-card level-b">

<h2>level B</h2>

<div class="percent-box">
1%
</div>

<p>Profit Ratio</p>

</div>

</div>

</div>

</body>
</html>